fruits = ["Apple", "Banana", "Chery"]

for x in fruits:
    print(x)