for x in range(0, 10, 2):
    print(x)