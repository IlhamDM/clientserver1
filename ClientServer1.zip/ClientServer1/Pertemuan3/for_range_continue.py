for x in range(0, 10):
    if x % 2 == 0:
        continue
    print(x)