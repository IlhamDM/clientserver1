class SegiTiga:
