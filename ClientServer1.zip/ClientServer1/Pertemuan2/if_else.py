nilai = -9

if nilai >= 0:
    print("Nilai bernilai Positif")
else:
    print("Nilai bernilai Negatif")
